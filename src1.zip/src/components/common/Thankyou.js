import React from 'react'

export default function Thankyou() {
  return (
    <div>
      
    </div>
  )
}
